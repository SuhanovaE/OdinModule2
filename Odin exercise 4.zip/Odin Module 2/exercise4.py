n = int(input())
dict_files = dict()
for _ in range(n):
    list_line = input().split()
    dict_files[list_line[0]] = list_line[1:]

m = int(input())
for _ in range(m):
    operation, file_name = input().split()
    if operation == 'read':
        oper_letter = 'R'
    elif operation == 'write':
        oper_letter = 'W'
    elif operation == 'execute':
        oper_letter = 'X'
    for k in dict_files:
        if k == file_name:
            if oper_letter in dict_files[file_name]:
                print('OK')
            else:
                print('Access denied')
