m = int(input())
n = int(input())
list_power = []
for i in range(n):
    list_power.append(int(input()))

first_number = 0
second_number = 0
max_multiply = 1

for i in range(0, len(list_power)-2):
    for j in range(i+1, len(list_power)):
        summa = list_power[i]+list_power[j]
        multiply = list_power[i]+list_power[j]
        if summa % m == 0:
            if multiply > max_multiply:
                first_number = list_power[i]
                second_number = list_power[j]
                max_multiply = multiply

print(first_number, second_number)

