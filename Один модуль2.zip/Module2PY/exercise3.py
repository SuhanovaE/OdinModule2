n, m = [int(c) for c in input().split()]
list_pixels = []
summa = 0
for i in range(n):
    line = [int(c) for c in input().split()]
    list_pixels.append(line)
    summa += sum(line)
avg_pixel = summa/(n*m)
print(avg_pixel)
for i in range(n):
    for j in range(m):
        if list_pixels[i][j] < avg_pixel:

