dict_voice = dict()
n = int(input())
list_voice = [int(v) for v in input().split()]
for item in list_voice:
    if item in range(1, n + 1):
        if item not in dict_voice:
            dict_voice[item] = 1
        else:
            dict_voice[item] += 1

max_voice = max(dict_voice.values())
for k, d in dict_voice.items():
    if d == max_voice:
        print(k, end=' ')
