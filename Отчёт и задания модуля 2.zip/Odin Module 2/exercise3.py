n, m = [int(x) for x in input().split()]
list_pixel = []
summa = 0
for i in range(n):
    line = [int(x) for x in input().split()]
    list_pixel.append(line)
    summa += sum(line)
avg_pixel = round(summa / (n * m), 4)
print(f'{avg_pixel}')
for i in range(n):
    for j in range(m):
        if list_pixel[i][j] < avg_pixel:
            list_pixel[i][j] = 0
        else:
            list_pixel[i][j] = 255
        print(list_pixel[i][j], end=' ')
    print()
