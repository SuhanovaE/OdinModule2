n = int(input())
dict_file = dict()
for _ in range(n):
    list_line = input().split()
    dict_file[list_line[0]] = list_line[1:]

m = int(input())
for _ in range(m):
    operation, file_name = input().split()
    if operation == 'write':
        operation_letter = 'W'
    elif operation == 'read':
        operation_letter = 'R'
    elif operation == 'execute':
        operation_letter = 'X'
    for k in dict_file:
        if k == file_name:
            if operation_letter in dict_file[file_name]:
                print('OK')
            else:
                print('Access denied')
